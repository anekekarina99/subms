const base_url = "https://api.football-data.org/v2";
const api_token = "5c8067d28a814255a4ba1d98827833f3";
const id_ligaChamp = 2001;
const id_ligaIng =  2021;
const id_ligaSpan = 2014;

const riwayat_tim = "timf";

const e_stand = `${base_url}/competitions/${id_ligaChamp}/standings?standingType=TOTAL`;
const e_stand2 = `${base_url}/competitions/${id_ligaIng}/standings?standingType=TOTAL`;
const e_stand3 = `${base_url}/competitions/${id_ligaSpan}/standings?standingType=TOTAL`;
const e_tim = `${base_url}/teams/`;

function status(response) {
    if (response.status !== 200) {
        console.log("Status : " + response.status);
        return Promise.reject(new Error(response.statusText));
    } else {
        return Promise.resolve(response);
    }
}
function json(response) {
    return response.json();
}

function error(error) {
    console.log(" Error : " + error);
}

function fetchAPI(endpoint) {
    return fetch(endpoint, {
        headers: {
            "X-Auth-Token": api_token
        }
    });
}

//ambil Tim liga Champion

function ambilTim() {
    return new Promise(function(resolve, reject) {
        if ("caches" in window) {
            caches.match(e_stand).then(function(response) {
                if (response) {
                    response.json().then(function(data) {
                        ambilTimJSON(data);
                        resolve(data);
                    });
                }
            });
        }
    
        fetchAPI(e_stand)
            .then(status)
            .then(json)
            .then(function(data) {
                ambilTimJSON(data)
                resolve(data);
            })
    
        .catch(error);
    });
   
}

//ambil Tim JSON liga Champion

function ambilTimJSON(data){
  
    console.log(data);
    let tim = '';

    data.standings.forEach(team => {

        team.table.forEach(team=>{

            team = JSON.parse(JSON.stringify(team).replace(/^http:\/\//i, 'https://'));  
    
        
            tim += `<div class="row">
            <div class="col s12 m7">
              <div class="card">
                <div class="card-content">
                  <p>${team.team.name}</p>
                </div>
                <div class="card-action ">
                  <a class="center-align waves-effect" href="./riwayat_tim.html?id=${team.team.id}">Detail</a>
                </div>
              </div>
            </div>
          </div>
           `
        })  

    })
    document.getElementById('timD').innerHTML= tim;
}

//ambil Tim liga Ing

function ambilTimIng() {
    return new Promise(function(resolve, reject) {
        if ("caches" in window) {
            caches.match(e_stand2).then(function(response) {
                if (response) {
                    response.json().then(function(data) {
                        ambilTimJSONIng(data);
                        resolve(data);
                    });
                }
            });
        }
    
        fetchAPI(e_stand2)
            .then(status)
            .then(json)
            .then(function(data) {
                ambilTimJSONIng(data)
                resolve(data);
            })
    
        .catch(error);
    });
   
}

//ambil Tim JSON liga ing

function ambilTimJSONIng(data){
  
    console.log(data);
    let tim = '';

    data.standings.forEach(team => {

        team.table.forEach(team=>{

            team = JSON.parse(JSON.stringify(team).replace(/^http:\/\//i, 'https://'));  
    
        
            tim += `<div class="row">
            <div class="col s12 m7">
              <div class="card">
                <div class="card-content">
                  <p>${team.team.name}</p>
                </div>
                <div class="card-action ">
                  <a class="center-align waves-effect" href="./riwayat_tim1.html?id=${team.team.id}">Detail</a>
                </div>
              </div>
            </div>
          </div>
           `
        })  

    })
    document.getElementById('tim').innerHTML= tim;
}

//ambil Tim liga Spanyol

function ambilTimSpan() {
    return new Promise(function(resolve, reject) {
        if ("caches" in window) {
            caches.match(e_stand3).then(function(response) {
                if (response) {
                    response.json().then(function(data) {
                        ambilTimJSONSpan(data);
                        resolve(data);
                    });
                }
            });
        }
    
        fetchAPI(e_stand3)
            .then(status)
            .then(json)
            .then(function(data) {
                ambilTimJSONSpan(data)
                resolve(data);
            })
    
        .catch(error);
    });
   
}

//ambil Tim JSON liga Span

function ambilTimJSONSpan(data){
  
    console.log(data);
    let tim = '';

    data.standings.forEach(team => {

        team.table.forEach(team=>{

            team = JSON.parse(JSON.stringify(team).replace(/^http:\/\//i, 'https://'));  
    
        
            tim += `<div class="row">
            <div class="col s12 m7">
              <div class="card">
                <div class="card-content">
                  <p>${team.team.name}</p>
                </div>
                <div class="card-action ">
                  <a class="center-align waves-effect" href="./riwayat_tim2.html?id=${team.team.id}">Detail</a>
                </div>
              </div>
            </div>
          </div>
           `
        })  

    })
    document.getElementById('tim').innerHTML= tim;
}

//ambil Tim Detail (umum)

function ambilTimDetail(id_tim) {
    return new Promise(function(resolve, reject) {
        if ("caches" in window) {
            caches.match(e_tim+id_tim).then(function(response) {
                if (response) {
                    response.json().then(function(data) {
                        ambilTimDetailJSON(data);
                        resolve(data);
                    });
                }
            });
        }
    
        fetchAPI(e_tim+id_tim)
            .then(status)
            .then(json)
            .then(function(data) {
                ambilTimDetailJSON(data)
                resolve(data);
            })
    
        .catch(error);
    });
   
}

//ambil Tim Detail JSON (umum)
function ambilTimDetailJSON(data){
  
    console.log(data);
    let detail_tab = '';

    data = JSON.parse(JSON.stringify(data).replace(/^http:\/\//i, 'https://'));
        
            detail_tab += `
            <div class="parallax-container">
              <div class="parallax"><img src="/images/ball.jpg"></div>
            </div>
            <div class="section white">
              <div class="row container">
                <h2 class="header">${data.name}</h2>
                <p class="grey-text text-darken-3 lighten-3"> Nama Tim berikut adalah <span class="green accent-3"> ${data.name}</span>, kependekan  adalah  <span>${data.shortName}</span></p>
                <a class="btn waves-effect waves-light" href="./index.html">Kembali
  <i class="material-icons right">chevron_left</i>
</a>
                </div>
            </div>
            <div class="parallax-container">
              <div class="parallax"><img src="/images/ball.jpg"></div>
            </div>
           `
           ;
    
document.getElementById('timD').innerHTML= detail_tab;
}

//simpan riwayat jenis tim
function simpanRiwayat(ID, riwayat_jenis){
    if(riwayat_jenis== riwayat_tim){
        simpanRiwayat(ID,tab_riwayat_name).then(
            function(data){
                ambilTimDetail(data);
            }
        )
    }
}

//fungsi wadahRiwayat

function riwayat(type){
    if(type==riwayat_tim){
        ambilRiwayat(tab_riwayat_name).then(function (data){
            data = JSON.parse(JSON.stringify(data).replace(/^http:\/\//i, 'https://'));

            let riwayat_tim_book ='';
            data.forEach(function(riwayat_tim){
                riwayat_tim__book += `
                <div class="card">
                <table>
                <thead>
                  <tr>
                      <th>Name Tim</th>
                      <th>Detail</th>
                  </tr>
                </thead>
        
                <tbody>
                  <tr>
                    <td>${riwayat_tim.name}</td>
                    <td><a class="pink accent-4"href="./riwayat_tim.html?id=${riwayat_tim.id}&saved=true">Detail</a></td>
                    <td> <a class="waves-effect waves-light btn-small red" onclick=hapusRiwayat(${riwayat_tim.id}, 'timf')">
                    <i class="large material-icons">clear</i>
                </a></td>
                  </tr>
                </tbody>
              </table>
              </div>`;
            });
            document.getElementById("riwayat").innerHTML= riwayat_tim_book;
        });
  
        }
        
    

    }

    
