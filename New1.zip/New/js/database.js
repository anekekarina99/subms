function cekDatabase(idb) {
    var dbPromised = idb.open("football-info", 1, function(upgradeDb) {    
        if (!upgradeDb.objectStoreNames.contains(tab_riwayat_tim)) {
            var riwayatO = upgradeDb.createObjectStore(tab_riwayat_tim, {
                keypath: "id"
            });
            
            riwayatO.createIndex("nama_tim", "nama", {
                unique: false
            });
        
                
        }

    });
    return dbPromised;
}

function tambahkeRiwayat(data,riwayat) {
    var dataPrimaryKey;
    if (riwayat == tab_riwayat_tim) {
        dataPrimaryKey = data.id;        
    }
    
    

    cekDatabase(idb)
        .then(function(db) {
            var tx = db.transaction(riwayat, "readwrite");
            var store = tx.objectStore(riwayat);
            
            store.put(data, dataPrimaryKey);

            return tx.complete;
        })
        .then(function() {
            M.toast({
                html: "Riwayat  ditambahkan",
            });
        });
}

function hapusRiwayat(id, riwayat) {
    console.log(id + " " + riwayat);
    cekDatabase(idb)
        .then(function(db) {
            var tx = db.transaction(riwayat ,"readwrite");
            var store = tx.objectStore(riwayat);

            store.delete(id_tim);

            return tx.complete;
        })
        .then(function() {
            M.toast({
                html: "Sudah dihapus :(",
            });
        });

    location.reload();
}

function ambilRiwayat(riwayat) {
    return new Promise(function(resolve, reject) {
        cekDatabase(idb)
            .then(function(db) {
                var tx = db.transaction(riwayat, "readonly");
                var store = tx.objectStore(riwayat);
                
                return store.getAll();
            })
            .then(function(data) {
                resolve(data);
            });
    });
}

function ambilId(id,riwayat){
    return new Promise(function(resolve, reject) {
        cekDatabase(idb)
            .then(function(db) {
                var tx = db.transaction(riwayat, "readonly");
                var store = tx.objectStore(riwayat);

                return store.get(id);
            })
            .then(function(data) {
                resolve(data);
            });
    });
}

