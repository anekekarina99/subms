document.addEventListener("DOMContentLoaded", function() {
    var urlParams = new URLSearchParams(window.location.search);
    var id_tim = Number(urlParams.get("id"));
    var simpan= urlParams.get("saved");

    var riwayat = document.getElementById("riwayat");
    if (simpan) {
       simpan.style.display = "none";
        simpanRiwayat(id_tim, "tim");
    } else {
        var item = ambilTimDetail(id_tim);
    }

  riwayat.onclick = function() {
        item.then(function(tim) {
            tambahkeRiwayat(tim, "timf");
        });
    };
});