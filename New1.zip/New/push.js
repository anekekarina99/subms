var webPush = require('web-push');
 
const vapidKeys = {
   "publicKey": "BBOqIDwHwmOUM3RImXTVNaSQkO8utUJFGCLl3p_-ehTRE8arYjEbFWW5xiC09eAu64wlPB1XG6fzplN6RHwG6lA",
   "privateKey": "M-ro4WyxlElKE8ba0M2OJOo6Nq_tmM1JHMOaUTeSL9k"
};
 
 
webPush.setVapidDetails(
   'mailto:example@yourdomain.org',
   vapidKeys.publicKey,
   vapidKeys.privateKey
)
var pushSubscription = {
   "endpoint": "<Endpoint URL>",
   "keys": {
       "p256dh": "<p256dh Key>",
       "auth": "<Auth key>"
   }
}; 
var payload = 'Selamat! Aplikasi Anda sudah dapat menerima push notifikasi!';
 
var options = {
   gcmAPIKey: '196223211019',
   TTL: 60
};
webPush.sendNotification(
 pushSubscription,
   payload,
   options
);