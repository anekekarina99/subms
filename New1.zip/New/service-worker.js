const CACHE_NAME = "football-info";
var urlsToCache = [
    "/",
    "/js/riwayat.js",
    "/manifest.json",
    "/nav.html",
    "/index.html",
    "/riwayat_tim2.html",
    "/riwayat_tim1.html",
    "/riwayat_tim.html",
    "/pages/beranda.html",
    "/pages/lanjut.html",
    "/pages/lanjut2.html",
    "/pages/riwayat.html",
    "/css/materialize.min.css",
    "/js/app.js",
    "/js/database.js",
    "/js/helper.js",
    "/js/idb.js",
    "/push.js",
    "/js/materialize.js",
    "/js/materialize.min.js",
    "/js/script.js",
    "/js/nav-effect.js",
    "/images/icons/icon-144x144.png",
    "/images/icons/icon-72x72.png",
    "/images/icons/icon-96x96.png",
    "/images/icons/icon-192x192.png",
    "/images/icons/icon-512x512.png",
    "/images/ball.jpg",
    "/images/bell.png",
    "https://code.jquery.com/jquery-2.1.1.min.js",
    "https://fonts.googleapis.com/css2?family=Fredoka+One&family=Quicksand:wght@700&display=swap",
    "https://unpkg.com/snarkdown@1.0.2/dist/snarkdown.umd.js",
    "https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.3/js/materialize.min.js",
    "https://fonts.googleapis.com/icon?family=Material+Icons",
    "https://fonts.gstatic.com/s/quicksand/v21/6xK-dSZaM9iE8KbpRA_LJ3z8mH9BOJvgkBgv58a-wg.woff2",
    "https://fonts.gstatic.com/s/materialicons/v55/flUhRq6tzZclQEJ-Vdg-IuiaDsNc.woff2",
];

self.addEventListener("install", function(event) {
    event.waitUntil(
        caches.open(CACHE_NAME).then(function(cache){
            return cache.addAll(urlsToCache);
        })
    );
});

self.addEventListener("fetch", function(event) {
    var base_url = "https://api.football-data.org/v2";

    if (event.request.url.indexOf(base_url) > -1) {
        event.respondWith(
            caches.open(CACHE_NAME).then(function(cache) {
                return fetch(event.request).then(function(response) {
                    cache.put(event.request.url, response.clone());

                    return response;
                })
            })
        );
    } else {
        event.respondWith(
            caches.match(event.request, { ignoreSearch: true }).then(function(response) {
                return response ||  fetch(event.request);
            })
        )
    }
});

self.addEventListener("activate", function(event) {
    event.waitUntil(
        caches.keys().then(function(cacheNames) {
            return Promise.all(
                cacheNames.map(function(cacheName) {
                    if (cacheName != CACHE_NAME) {
                        console.log("ServiceWorker: cache " + cacheName + "dihapus");
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});

self.addEventListener("push", function(event) {
    var body;
    
    if (event.data) {
        body = event.data.text();
    } else {
        body = "Push message no payload";
    }

    var options = {
        body: body,
        icon: " /images/bell.png",
        vibrate: [100, 50, 100],
        data: {
            dateOfArrival: Date.now(),
            primaryKey: 1
        }
    };

    event.waitUntil(
        self.registration.showNotification("Notifikasi Push", options)
    );
});